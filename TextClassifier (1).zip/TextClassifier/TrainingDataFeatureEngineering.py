from sklearn.model_selection import train_test_split
from sklearn import metrics

from sklearn.metrics import accuracy_score
import pandas as pd
import numpy as np



df_data_serialized = pd.read_pickle(r'F:\scrapedtext\preprocessed_dataset')

#shuffling the dataset
df_data = df_data_serialized.sample(frac=1)

processed = df_data['document'].tolist()

#print(words)

#Bag of words
#cv = CountVectorizer(max_features = 1500)
#
#X = cv.fit_transform(processed).toarray()
#y = df_data.iloc[:,1].values
#
#vocab = cv.get_feature_names()
#
#bow_df = pd.DataFrame(X,columns=vocab)
#
#print(bow_df)


#TF-IDF

from sklearn.feature_extraction.text import TfidfVectorizer
tv = TfidfVectorizer(max_features = 1500, min_df=0., max_df=1., use_idf=True)
tv_matrix = tv.fit_transform(processed)
tv_matrix = tv_matrix.toarray()
vocab = tv.get_feature_names()
X = pd.DataFrame(np.round(tv_matrix, 2), columns=vocab)

y = df_data.iloc[:,1].values

#print(X)

#print(tfidf_df)
#X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.20, random_state = 0)



#K-fold cross validation
from sklearn.model_selection import KFold 
kf = KFold(n_splits=10)

for train_index, test_index in kf.split(X,y):
      X_train, X_test = X.iloc[train_index], X.iloc[test_index] 
      y_train, y_test = y[train_index], y[test_index]



#Trying SVD
#Saving the training datasets for future use

np.save(r'F:\scrapedtext\Xtrain',X_train)
np.save(r'F:\scrapedtext\ytrain',y_train)


#Building training model with different classifiers
#==============================================================================
#Naive Bayes classifier
from sklearn.naive_bayes import GaussianNB
classifier = GaussianNB()
classifier.fit(X_train, y_train)

# Predicting the Test set results
y_pred = classifier.predict(X_test)

print(y_pred)

#Model Accuracy

print("Naive Bayes Accuracy:",metrics.accuracy_score(y_test, y_pred))
from sklearn.metrics import classification_report
rpt_nb = classification_report(y_test,y_pred)
print("Classification Report for Naive Bayes\n:",rpt_nb)

# Making the Confusion Matrix
#from sklearn.metrics import confusion_matrix
#cm_NB = confusion_matrix(y_test, y_pred)


from sklearn.linear_model import LogisticRegression
logreg = LogisticRegression(C=1e5, multi_class='auto', solver='lbfgs')
logreg.fit(X_train, y_train)

logpred = logreg.predict(X_test)

print(logpred)
print("Logistic Regression Accuracy:",metrics.accuracy_score(y_test, logpred))

#from sklearn.metrics import confusion_matrix
#log_cm = confusion_matrix(y_test, logpred)
#print("Confusion Matrix:\n",log_cm)

from sklearn.metrics import classification_report
rpt_lg = classification_report(y_test,logpred)
print("Classification Report for Logistic Regression\n:",rpt_lg)



#K-Nearest Neighbour (KNN) Classifier

from sklearn.neighbors import KNeighborsClassifier
neigh = KNeighborsClassifier(n_neighbors=3)
neigh.fit(X_train, y_train)

neighpred = neigh.predict(X_test)

print(neighpred)
print("KN Accuracy:",metrics.accuracy_score(y_test, neighpred))

from sklearn.metrics import classification_report
rpt_knn = classification_report(y_test,neighpred)
print("Classification Report for KNN\n:",rpt_knn)



#Decision Tree CLassifier

from sklearn.tree import DecisionTreeClassifier
dt = DecisionTreeClassifier(max_depth=10)
dt.fit(X_train, y_train)
dtpred = dt.predict(X_test)

print(dtpred)
print("Decision Tree Accuracy:",metrics.accuracy_score(y_test, dtpred))

from sklearn.metrics import classification_report
rpt_dt = classification_report(y_test,dtpred)
print("Classification Report for Decision Tree\n:",rpt_dt)



#Random Forest Classifier

from sklearn.ensemble import RandomForestClassifier
rf = RandomForestClassifier(max_depth=5, n_estimators=10, max_features=1)
rf.fit(X_train, y_train)
rfpred = rf.predict(X_test)

print(rfpred)
print("Random forest Accuracy:",metrics.accuracy_score(y_test, rfpred))

from sklearn.metrics import classification_report
rpt_rf = classification_report(y_test,rfpred,labels=[1, 2, 3])
print("Classification Report for Random Forest\n:",rpt_rf)





#Fitting Multilayer Perceptron Classifier

from sklearn.neural_network import MLPClassifier
mlp = MLPClassifier(alpha=1, max_iter=1000)

mlp.fit(X_train, y_train)

mlppred = mlp.predict(X_test)

print(mlppred)
print("BP MLP Accuracy:",metrics.accuracy_score(y_test, mlppred))

from sklearn.metrics import classification_report
rpt_mlp = classification_report(y_test,mlppred)
print("Classification Report for BPMLP\n:",rpt_mlp)












