from TestDataScrapper import build_dataset_test
from TestDataPreprocessor import preprocess_test_dataset
from TestDataFeatureEngineering import testdata_featureengineering
import pandas as pd
import numpy as np



#Scraping test data from test website
testdataframe = build_dataset_test("https://www.firstpost.com/sports/australian-open-2020-sania-mirza-retires-mid-way-into-womens-doubles-first-round-clash-due-to-calf-injury-7945391.html")
print(testdataframe)

#Preprocessing test data
testdata_clean = preprocess_test_dataset(testdataframe)

testdata_preprocessed = pd.DataFrame(testdata_clean, columns=['document'])

#Extracting features from preprocessed data
X_testdata = testdata_featureengineering(testdata_preprocessed)

#PCA on testdata
from sklearn.decomposition import PCA
pca = PCA(n_components_=39) #95% of variance maintained

pca.fit(X_testdata)

print("No. of principal components after reduction: ", pca.n_components_)

X_testdata = pca.transform(X_testdata)
#Re-loading the saved training datasets to re-train the model
X_train = np.load(r'F:\scrapedtext\Xtrain.npy',allow_pickle=True)
y_train = np.load(r'F:\scrapedtext\ytrain.npy',allow_pickle=True)

from sklearn.naive_bayes import GaussianNB
classifier = GaussianNB()
classifier.fit(X_train, y_train)

y_pred = classifier.predict(X_testdata)
print(y_pred)

