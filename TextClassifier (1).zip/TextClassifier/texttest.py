import re
#import pandas as pd
#
#
#
#
#
#df_raw = pd.read_pickle(r'F:\scrapedtext\rawdataset')
#
#con = df_raw['content']
#print(con)
#
#for doc in df_raw['content']:
#    doc = doc.lower()
#    df_raw['content'].values = doc
#
#print(df_raw)


text = "BCCIViratKohliCricketFootball"
s = re.findall(r'[A-Z](?:[A-Z]*(?![a-z])|[a-z]*)', text)
listToStr = ' '.join(map(str, s)) 
print(listToStr)