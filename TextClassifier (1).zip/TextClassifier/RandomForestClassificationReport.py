from sklearn import metrics
import pandas as pd
import numpy as np



df_data_serialized = pd.read_pickle(r'F:\scrapedtext\preprocessed_dataset')

#shuffling the dataset
df_data = df_data_serialized.sample(frac=1)

processed = df_data['document'].tolist()


from sklearn.feature_extraction.text import TfidfVectorizer
tv = TfidfVectorizer(max_features = 1500, min_df=0., max_df=1., use_idf=True)
tv_matrix = tv.fit_transform(processed)
tv_matrix = tv_matrix.toarray()
vocab = tv.get_feature_names()
X = pd.DataFrame(np.round(tv_matrix, 2), columns=vocab)

y = df_data.iloc[:,1].values


#K-fold cross validation
from sklearn.model_selection import KFold 
kf = KFold(n_splits=10)

for train_index, test_index in kf.split(X,y):
      X_train, X_test = X.iloc[train_index], X.iloc[test_index] 
      y_train, y_test = y[train_index], y[test_index]


#==============================================================================

#random forest

from sklearn.ensemble import RandomForestClassifier
rf = RandomForestClassifier(max_depth=5, n_estimators=10, max_features=1)
rf.fit(X_train, y_train)
rfpred = rf.predict(X_test)

print(rfpred)
print("Random forest Accuracy:",metrics.accuracy_score(y_test, rfpred))

from sklearn.metrics import classification_report
rpt_rf = classification_report(y_test,rfpred,labels=[1, 2, 3])
print("Classification Report for Random Forest\n:",rpt_rf)





