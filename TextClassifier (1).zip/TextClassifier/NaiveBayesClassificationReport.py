from sklearn import metrics
import pandas as pd
import numpy as np



df_data_serialized = pd.read_pickle(r'F:\scrapedtext\preprocessed_dataset')

#shuffling the dataset
df_data = df_data_serialized.sample(frac=1)

processed = df_data['document'].tolist()


from sklearn.feature_extraction.text import TfidfVectorizer
tv = TfidfVectorizer(max_features = 1500, min_df=0., max_df=1., use_idf=True)
tv_matrix = tv.fit_transform(processed)
tv_matrix = tv_matrix.toarray()
vocab = tv.get_feature_names()
X = pd.DataFrame(np.round(tv_matrix, 2), columns=vocab)

y = df_data.iloc[:,1].values


#K-fold cross validation
from sklearn.model_selection import KFold 
kf = KFold(n_splits=10)

for train_index, test_index in kf.split(X,y):
      X_train, X_test = X.iloc[train_index], X.iloc[test_index] 
      y_train, y_test = y[train_index], y[test_index]


#==============================================================================
#Naive Bayes classifier
from sklearn.naive_bayes import GaussianNB
classifier = GaussianNB()
classifier.fit(X_train, y_train)

# Predicting the Test set results
y_pred = classifier.predict(X_test)

print(y_pred)

#Model Accuracy

print("Naive Bayes Accuracy:",metrics.accuracy_score(y_test, y_pred))
from sklearn.metrics import classification_report
rpt_nb = classification_report(y_test,y_pred)
print("Classification Report for Naive Bayes\n:",rpt_nb)
