import re
import nltk
from nltk.tokenize.toktok import ToktokTokenizer
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
from nltk.stem import WordNetLemmatizer
import string, unicodedata
import pandas as pd

lemmatizer = WordNetLemmatizer() 
tokenizer = ToktokTokenizer()



def remove_nonunicode_char(text):
    text = unicodedata.normalize('NFKD', text).encode('ascii', 'ignore').decode('utf-8', 'ignore')
    return text

def expand_contractions(text):

    text = re.sub(r"won\'t", "will not", text)
    text = re.sub(r"can\'t", "can not", text)

    # general
    text = re.sub(r"n\'t", " not", text)
    text = re.sub(r"\'re", " are", text)
    text = re.sub(r"\'s", " is", text)
    text = re.sub(r"\'d", " would", text)
    text = re.sub(r"\'ll", " will", text)
    text = re.sub(r"\'t", " not", text)
    text = re.sub(r"\'ve", " have", text)
    text = re.sub(r"\'m", " am", text)
    
    return text

def remove_numbers(text):
    text = re.sub(r'\d+', '', text)
    return text

def remove_punctuations(text):
    translator = str.maketrans('', '', string.punctuation)
    text = text.translate(translator)
    return text

def lemmatize_text(text):
    word_tokens = tokenizer.tokenize(text)
    text = ' '.join([lemmatizer.lemmatize(word, pos ='v') for word in word_tokens])
    return text

def stem_text(text):
    ps = nltk.porter.PorterStemmer()
    text = ' '.join([ps.stem(word) for word in text.split()])
    return text

stopword_list = nltk.corpus.stopwords.words('english')
def remove_stopwords(text, is_lower_case=False):
    tokens = tokenizer.tokenize(text)
    tokens = [token.strip() for token in tokens]
    if is_lower_case:
        filtered_tokens = [token for token in tokens if token not in stopword_list]
    else:
        filtered_tokens = [token for token in tokens if token.lower() not in stopword_list]
        
    #Removing blanks from here
    while("" in filtered_tokens):
        filtered_tokens.remove("")
    filtered_text = ' '.join(filtered_tokens)
    return filtered_text   


def preprocess_dataset(corpus, nonunicode_char_removal=True, contraction_expansion=True, 
                       number_removal=True, punctuation_removal=True, lower_case=True, 
                       text_lemmatization=True, text_stemming=True, stopword_removal=True):

    df_content = corpus['content']
    processed_data =[]
    
    #Preprocess each document in the corpus
    for doc in df_content:
        #remove nonunicode characters
        if nonunicode_char_removal:
            doc = remove_nonunicode_char(doc)
        
        #expand contractions
        if contraction_expansion:
            doc = expand_contractions(doc)
            
        #remove numbers
        if number_removal:
            doc = remove_numbers(doc)
        
        #remove punctuations
        if punctuation_removal:
            doc = remove_punctuations(doc)
        
        #change text to lowercase
        if lower_case:
            doc = doc.lower()
        
        #lemmatize text
        if text_lemmatization:
            doc = lemmatize_text(doc)
        
        #stem text
        if text_stemming:
            doc = stem_text(doc)

        #remove stopwords
        if stopword_removal:
            doc = remove_stopwords(doc, is_lower_case=lower_case)
            
        processed_data.append(doc)
        
    return processed_data

#Preprocessing the scraped data

df_raw = pd.read_pickle(r'F:\scrapedtext\rawdataset')
clean_data = preprocess_dataset(df_raw)

df_preprocessed = pd.DataFrame(clean_data, columns=['document'])

df_preprocessed.to_pickle(r'F:\scrapedtext\preprocessed_dataset')






















