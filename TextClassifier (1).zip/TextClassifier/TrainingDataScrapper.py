from urllib.request import Request, urlopen
from bs4 import BeautifulSoup
import pandas as pd
import re

seed_url_sports = ['https://timesofindia.indiatimes.com/sports',
                   'https://www.thehindu.com/todays-paper/tp-sports/',
                   'https://www.thehindu.com/sport/cricket/tendulkar-in-contention-for-laureus-sporting-moment-of-last-two-decades/article30542681.ece',
                   'https://www.thehindu.com/sport/football/',
                   'https://www.thehindu.com/sport/hockey/',
                   'https://www.thestatesman.com/sports',
                   'http://www.espn.com/espn/latestnews',
                   'https://edition.cnn.com/sport',
                   'https://www.foxnews.com/sports',
                   'https://www.thecricketer.com/international.html',
                   'https://www.cricindeed.com/what-makes-ashes-series-so-special/',
                   'https://www.cricindeed.com/what-is-a-good-batting-average-in-cricket/',
                   'https://www.cricindeed.com/inspiring-story-of-don-bradman/',
                   'https://www.cricindeed.com/steve-smith-batting-technique/',
                   'https://www.cricindeed.com/top-cricketers-of-2018/',
                   'https://weaintgotnohistory.sbnation.com/2014/2/20/5421790/eden-hazard-profile-feature',
                   'https://www.sport24.co.za/soccer',
                   'https://www.espn.in/nfl/story/_/id/28517879/super-bowl-liv-predictions-picks-odds-big-questions-49ers-chiefs',
                   'https://www.espn.in/nba/story/_/id/28485732/zion-williamson-preparation-preservation-no-precedent',
                   'https://www.espn.in/f1/story/_/id/28481829/race-saudi-arabia-looking-likely'
                   ]

seed_url_styleandfashion = [  
                                'https://fashionmagazine.com/style-panel/',
                                'https://www.thebalancecareers.com/magazines-for-fashion-models-to-study-2379467',
                                'https://en.wikipedia.org/wiki/List_of_fashion_magazines',        
                                'https://www.stackmagazines.com/fashion-style/the-10-best-independent-fashion-magazines-in-the-world-right-now/',
                                'https://www.glamourmagazine.co.uk/?international',
                                'https://en.wikipedia.org/wiki/2000s_in_fashion',
                                'https://www.telegraphindia.com/culture/style/adhuna-bhabani-on-bridal-hairstyles/cid/1736688?ref=more-from-style_culture-style-page',
                                'https://www.telegraphindia.com/culture/giving-a-new-lease-of-life-to-the-handloom-sector/cid/1718696',
                                'https://www.express.co.uk/life-style/style/1229196/ivanka-trump-news-donald-china-white-house-latest-pictures-outfit',
                                'https://www.express.co.uk/life-style/style/1224382/Golden-Globes-2020-red-carpet-best-dressed',
                                'https://www.pinkvilla.com/fashion/celebrity-style/hina-khan-shivangi-joshi-nia-sharma-best-worst-dressed-week-tv-501094',
                                'https://www.pinkvilla.com/fashion/celebrity-style/jean-paul-gaultier-s-upcoming-show-paris-fashion-week-will-mark-his-exit-designing-clothes-501001',
                                'https://www.fibre2fashion.com/industry-article/7924/fashionable-fusion-wear-for-preteens',
                                'https://www.hindustantimes.com/fashion-and-trends/boyhood-and-theatrics-mark-paris-fashion-week-men-s-shows/story-BCe8oWjkHABYQfBqHB4GjI.html',
                                'https://www.hindustantimes.com/fashion-and-trends/pongal-style-2020-temple-jewellery-traditional-silk-sarees-dhoti-sarees-and-more/story-TLE1xrnAJPxFdLoZj5IZhJ.html',
                                'http://www.bbc.com/culture/story/20191218-what-will-we-be-wearing-in-2020',
                                'https://edition.cnn.com/style/article/marilyn-monroe-white-dress-remember-when/index.html',
                                'https://edition.cnn.com/style/article/mama-cax-death-intl-scli/index.html',
                                'https://en.wikipedia.org/wiki/Fashion_in_India',
                                'https://en.wikipedia.org/wiki/Fashion_in_the_United_States'

                            ]

seed_url_businessandeconomics = [   
                                  'https://www.thehindu.com/business/Economy/',
                                  'https://www.thehindu.com/business/agri-business/',
                                  'https://www.thehindu.com/business/Economy/slowdown-temporary-reforms-undertaken-will-reverse-trend-mukesh-ambani/article29826019.ece',
                                  'https://www.thehindu.com/business/Economy/retail-inflation-jumps-to-735-in-december-crosses-rbis-comfort-level/article30558427.ece',
                                  'https://economictimes.indiatimes.com/news/economy/finance/nabard-projects-bengals-credit-potential-at-rs-191289-crore/articleshow/73330918.cms',
                                  'https://www.thelondoneconomic.com/business-economics/business/british-airways-owner-lodges-complaint-with-eu-over-flybe-rescue-deal/15/01/',
                                  'https://www.thelondoneconomic.com/business-economics/johnsons-brexit-would-shrink-economy-by-1000-per-household-damning-assessment-reveals/12/12/',
                                  'https://economictimes.indiatimes.com/markets/stocks/news/share-market-update-mining-stocks-mixed-deccan-gold-mines-surges-9nbspbr/articleshow/73324236.cms',
                                  'https://economictimes.indiatimes.com/markets/live-coverage',
                                  'https://timesofindia.indiatimes.com/business/india-business/unitech-promoters-diverted-money-of-home-buyers-and-banks-to-off-shore-tax-havens-audit-report/articleshow/73342712.cms',
                                  'https://timesofindia.indiatimes.com/business/india-business/sensex-rises-147-points-to-close-at-41600-nifty-above-12250/articleshow/73188301.cms',
                                  'https://www.thestatesman.com/business/senior-citizens-appeal-raise-interest-fds-1502772422.html',
                                  'https://en.wikipedia.org/wiki/Business_economics',
                                  'https://www.sciencedirect.com/science/article/pii/S0148619518300961',
                                  'https://www.omicsonline.org/business-and-economics-journal.php',
                                  'https://www.cleanlink.com/sm/article/How-To-Speed-Up-Sales-Performance--24777',
                                  'https://articles.bplans.com/know-your-industry-before-you-start-your-business/',
                                  'https://www.omicsonline.org/entrepreneurship-organization-management.php',
                                  'https://articles.bplans.com/business-ideas/7-steps-to-starting-your-own-business/',
                                  'https://articles.bplans.com/the-complete-guide-to-choosing-your-business-structure/'
                                  
                              ]




def build_dataset_sports(seed_url_sports):
    sports_data = []
    for url in seed_url_sports:
        url_to_parse = Request(url, headers={'User-Agent': 'Mozilla/5.0 (X11; U; Linux i686) Gecko/20071127 Firefox/2.0.0.11'})
        html_raw = urlopen(url_to_parse).read()
        webpage = html_raw.decode('utf-8')
        soup = BeautifulSoup(webpage, features="lxml")
        #For removing the scrips and style tags
        for script in soup(["script", "style"]):
            script.extract()

        # get raw text
        text = soup.body.get_text()

        # break into lines and remove leading and trailing space on each
        lines = (line.strip() for line in text.splitlines())

        # break multi-headlines into a single line

        chunks = (phrase.strip() for line in lines for phrase in line.split("  "))

        # drop blank lines
        text = '\n'.join(chunk for chunk in chunks if chunk)
        
        #Fixed the word concatenation issue - Splitting at uppercase while 
        #keeping abbreviations intact
        listSplits = re.findall(r'[A-Z](?:[A-Z]*(?![a-z])|[a-z]*)', text)
        listToStr = ' '.join(map(str, listSplits))
        
        sports_data.append(listToStr)
        
        sports_dict = {'content':sports_data,'category':1}
        
        df = pd.DataFrame(sports_dict)
        
        
    return df

def build_dataset_styleandfashion(seed_url_styleandfashion):
    style_data = []
    for url in seed_url_styleandfashion:
        url_to_parse = Request(url, headers={'User-Agent': 'Mozilla/5.0 (X11; U; Linux i686) Gecko/20071127 Firefox/2.0.0.11'})
        html_raw = urlopen(url_to_parse).read()
        webpage = html_raw.decode('utf-8')
        soup = BeautifulSoup(webpage, features="lxml")
        for script in soup(["script", "style"]):
            script.extract()

        # get raw text
        text = soup.body.get_text()

        # break into lines and remove leading and trailing space on each
        lines = (line.strip() for line in text.splitlines())

        # break multi-headlines into a single line

        chunks = (phrase.strip() for line in lines for phrase in line.split("  "))

        # drop blank lines
        text = '\n'.join(chunk for chunk in chunks if chunk)
        
        #Fixed the word concatenation issue - Splitting at uppercase while 
        #keeping abbreviations intact
        listSplits = re.findall(r'[A-Z](?:[A-Z]*(?![a-z])|[a-z]*)', text)
        listToStr = ' '.join(map(str, listSplits))
        
        style_data.append(listToStr)
        
        style_dict = {'content':style_data,'category':2}
        
        df = pd.DataFrame(style_dict)
        
        
    return df

def build_dataset_businessandeconomics(seed_url_businessandeconomics):
    business_data = []
    for url in seed_url_businessandeconomics:
        url_to_parse = Request(url, headers={'User-Agent': 'Mozilla/5.0 (X11; U; Linux i686) Gecko/20071127 Firefox/2.0.0.11'})
        html_raw = urlopen(url_to_parse).read()
        webpage = html_raw.decode('utf-8')
        soup = BeautifulSoup(webpage, features="lxml")
        for script in soup(["script", "style"]):
            script.extract()

        # get raw text
        text = soup.body.get_text()

        # break into lines and remove leading and trailing space on each
        lines = (line.strip() for line in text.splitlines())

        # break multi-headlines into a single line

        chunks = (phrase.strip() for line in lines for phrase in line.split("  "))

        # drop blank lines
        text = '\n'.join(chunk for chunk in chunks if chunk)
        
        #Fixed the word concatenation issue - Splitting at uppercase while 
        #keeping abbreviations intact
        listSplits = re.findall(r'[A-Z](?:[A-Z]*(?![a-z])|[a-z]*)', text)
        listToStr = ' '.join(map(str, listSplits))
        
        business_data.append(listToStr)
        
        business_dict = {'content':business_data,'category':3}
        
        df = pd.DataFrame(business_dict)
        
        
    return df

def build_dataset_test(test_url):
    test_data = []
    url_to_parse = Request(test_url, headers={'User-Agent': 'Mozilla/5.0 (X11; U; Linux i686) Gecko/20071127 Firefox/2.0.0.11'})
    html_raw = urlopen(url_to_parse).read()
    webpage = html_raw.decode('utf-8')
    soup = BeautifulSoup(webpage, features="lxml")
    for script in soup(["script", "style"]):
        script.extract()

        # get raw text
    text = soup.body.get_text()

        # break into lines and remove leading and trailing space on each
    lines = (line.strip() for line in text.splitlines())

        # break multi-headlines into a single line

    chunks = (phrase.strip() for line in lines for phrase in line.split("  "))

        # drop blank lines
    text = '\n'.join(chunk for chunk in chunks if chunk)
        
        #Fixed the word concatenation issue - Splitting at uppercase while 
        #keeping abbreviations intact
    listSplits = re.findall(r'[A-Z](?:[A-Z]*(?![a-z])|[a-z]*)', text)
    listToStr = ' '.join(map(str, listSplits))
        
    test_data.append(listToStr)
        
    test_dict = {'content':test_data}
        
    df = pd.DataFrame(test_dict)
        
    return df
    

    
sports_data = build_dataset_sports(seed_url_sports)
style_data = build_dataset_styleandfashion(seed_url_styleandfashion)
business_data = build_dataset_businessandeconomics(seed_url_businessandeconomics)

#Merge the three datasets into a single DataFrame
df_fulldataset_raw = pd.concat([sports_data, style_data, business_data],ignore_index=True)

#Save the DataFrame
df_fulldataset_raw.to_pickle(r'F:\scrapedtext\rawdataset')

#df_new = pd.read_pickle(r'F:\scrapedtext\rawdataset')

















