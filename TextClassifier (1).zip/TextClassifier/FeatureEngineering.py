import re
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
from nltk.stem import WordNetLemmatizer
from nltk.util import ngrams
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfVectorizer
import string, unicodedata
from textblob import TextBlob
import pandas as pd
import numpy as np



df_data = pd.read_pickle(r'F:\scrapedtext\preprocessed_dataset')

processed = df_data['document'].tolist()

#print(words)

#Bag of words
all_words = []

for message in processed:
    words = word_tokenize(message)
    for w in words:
        all_words.append(w)
        
all_words = nltk.FreqDist(all_words)
print(all_words)

print('Number of words: {}'.format(len(all_words)))
print('Most common words: {}'.format(all_words.most_common(15)))



# use the 1500 most common words as features
word_features = list(all_words.keys())[:1500]



















