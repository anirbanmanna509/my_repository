from sklearn.feature_extraction.text import TfidfVectorizer
import pandas as pd
import numpy as np



def testdata_featureengineering(testdata_preprocessed):
    testdata_shuffled = testdata_preprocessed.sample(frac=1)
    
    processed = testdata_shuffled['document'].tolist()
    
    tv = TfidfVectorizer(max_features = 273, min_df=0., max_df=1., use_idf=True)
    tv_matrix = tv.fit_transform(processed)
    tv_matrix = tv_matrix.toarray()
    vocab = tv.get_feature_names()
    X_unknown = pd.DataFrame(np.round(tv_matrix, 2), columns=vocab)
    
    return X_unknown
    
    