from urllib.request import Request, urlopen
from bs4 import BeautifulSoup
import pandas as pd
import re

def build_dataset_test(test_url):
    test_data = []
    url_to_parse = Request(test_url, headers={'User-Agent': 'Mozilla/5.0 (X11; U; Linux i686) Gecko/20071127 Firefox/2.0.0.11'})
    html_raw = urlopen(url_to_parse).read()
    webpage = html_raw.decode('utf-8')
    soup = BeautifulSoup(webpage, features="lxml")
    for script in soup(["script", "style"]):
        script.extract()

        # get raw text
    text = soup.body.get_text()

        # break into lines and remove leading and trailing space on each
    lines = (line.strip() for line in text.splitlines())

        # break multi-headlines into a single line

    chunks = (phrase.strip() for line in lines for phrase in line.split("  "))

        # drop blank lines
    text = '\n'.join(chunk for chunk in chunks if chunk)
        
        #Fixed the word concatenation issue - Splitting at uppercase while 
        #keeping abbreviations intact
    listSplits = re.findall(r'[A-Z](?:[A-Z]*(?![a-z])|[a-z]*)', text)
    listToStr = ' '.join(map(str, listSplits))
        
    test_data.append(listToStr)
        
    test_dict = {'content':test_data}
        
    df = pd.DataFrame(test_dict)
        
    return df